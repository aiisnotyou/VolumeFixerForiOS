//
//  volumeFixerApp.swift
//  volumeFixer
//
//  Created by WorkingMind on 6/1/26.
//

import SwiftUI

@main
struct volumeFixerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
